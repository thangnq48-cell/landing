FPT LANDING PAGE — 1.8.1
========================
Shortcode: [fpt_landing_page]

SỬA LỖI TRONG 1.8.1
- Lưu biểu mẫu: chỉ mở nhóm và tập trung vào ô không hợp lệ đầu tiên.
- Không ẩn nhầm quyền lợi khi dữ liệu cũ có ô trống xen giữa.
- Tiêu đề đăng ký trong cài đặt nay được áp dụng cho popup.
- ID của popup và biểu mẫu không trùng khi dùng nhiều shortcode.
- Tránh gắn lặp sự kiện frontend; giữ tiêu đề khi chuyển qua chế độ gọi lại.
- Hiển thị thông báo lưu của WordPress trên trang cài đặt.
- Tái sử dụng cửa sổ chọn ảnh; xóa lựa chọn cũ trước mỗi lần mở.
- Khách đăng ký chỉ được truy cập bằng quyền manage_options, tương tự
  trang quản trị plugin. Tài khoản biên tập viên mặc định sẽ không xem
  được thông tin khách hàng qua đường dẫn quản trị trực tiếp.
- Giữ nguyên CSS, bố cục và các trường trong popup.

THAY ĐỔI TỪ 1.8.0
- Quản lý gói cước bằng các trường riêng: tên, giá, tốc độ tải xuống,
  tốc độ tải lên, nhãn nổi bật và liên kết chi tiết.
- Mỗi quyền lợi là một ô nhập. Có nút thêm / xóa quyền lợi.
- Thêm, xóa, thu gọn và đổi thứ tự từng gói trong 5 nhóm dịch vụ.
- Ảnh banner và ảnh gói cước: chọn / tải lên qua thư viện WordPress,
  xem trước ngay, đổi hoặc gỡ ảnh.
- Đọc dữ liệu dạng dòng của bản cũ. Khi lưu, nhóm gói được lưu thành
  các trường có cấu trúc; không phải nhập ký tự phân cách | hoặc ;.
- Giữ nguyên giao diện landing page, popup đăng ký / gọi lại,
  xử lý khách đăng ký và email thông báo.

CÁCH DÙNG
1. WordPress > FPT Landing Page > Quản lý gói cước.
2. Chọn nhóm cần sửa; nhập các trường trong từng thẻ gói.
3. Giá: ví dụ 195.000đ. Tốc độ: ví dụ 300 Mbps hoặc 1 Gbps.
4. Chọn ảnh, chọn trong thư viện hoặc tải lên, bấm Dùng ảnh này.
5. Bấm Lưu tất cả gói cước. Các thay đổi chỉ áp dụng sau khi lưu.

Mỗi nhóm vẫn hiển thị tối đa 6 gói đầu trên landing page.
Các gói vượt quá 6 vẫn được lưu và có thể chuyển lên trên.
Gỡ ảnh chỉ bỏ ảnh khỏi banner / gói, không xóa tệp trong thư viện.
Gỡ banner sẽ dùng hình minh họa mặc định.

CẬP NHẬT
Sao lưu cơ sở dữ liệu và plugin hiện tại. Vào Plugins > Add New >
Upload Plugin, chọn FPT-Landing-v1.8.1.zip và thay thế phiên bản cũ.
Giữ nguyên thư mục fpt-landing-plugin. Không cần xóa plugin trước.
Sau cập nhật, kiểm tra các nhóm gói và chọn ảnh trên website của bạn.
Nếu khôi phục bản 1.7.7 sau khi đã lưu gói bằng 1.8.0, khôi phục cả
bản sao cài đặt / cơ sở dữ liệu trước cập nhật vì định dạng lưu đã đổi.

KIỂM TRA PHÁT TRIỂN
Đã kiểm tra cú pháp PHP / JavaScript, đọc dữ liệu cũ, lưu dữ liệu mới,
đổi thứ tự và các thao tác quản trị trong môi trường mô phỏng API
WordPress / Media. Chưa kiểm thử tích hợp trên một website WordPress
thực tế. Bản 1.8.1 đạt 52 kiểm tra PHP / DOM mô phỏng cùng kiểm tra cú pháp.
CSS frontend không thay đổi. Các sửa đổi JavaScript / markup popup
chỉ xử lý tiêu đề, ID và sự kiện; không thay đổi bố cục.
