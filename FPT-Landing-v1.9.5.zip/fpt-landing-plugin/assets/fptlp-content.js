(function () {
  'use strict';
  function init() {
    document.querySelectorAll('.fptlp .fptlp-article-details').forEach(function (details) {
      if (details.dataset.fptlpContentReady) return;
      details.dataset.fptlpContentReady='1';
      var button=details.querySelector('.fptlp-article-collapse');
      button.hidden=false;
      button.addEventListener('click',function () {
        details.open=false;
        details.querySelector('summary').focus({preventScroll:true});
        details.querySelector('summary').scrollIntoView({block:'nearest',behavior:'auto'});
      });
    });
  }
  if (document.readyState==='loading') document.addEventListener('DOMContentLoaded',init); else init();
})();
