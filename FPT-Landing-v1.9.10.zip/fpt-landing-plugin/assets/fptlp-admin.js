jQuery(function ($) {
  'use strict';
  var root = document.querySelector('.fptlp-admin');
  if (!root) return;
  var counter = 0;
  var dirty = false;
  var mediaFrame = null;
  var mediaField = null;
  var form = root.querySelector('form');
  function changed() { dirty = true; var status=root.querySelector('.fptlp-save-bar span');if(status){status.textContent='Có thay đổi chưa lưu.';status.setAttribute('role','status');} }
  function announce(text) { $(root).find('.fptlp-admin-status').text(text); }
  function show(key) {
    $(root).find('.fptlp-admin-tab').each(function () {
      var active = this.dataset.adminTab === key;
      $(this).toggleClass('button-primary', active).attr('aria-pressed', String(active));
    });
    $(root).find('.fptlp-admin-category').each(function () { this.hidden = this.dataset.adminPanel !== key; });
  }
  function update(panel) {
    var cards = $(panel).find('.fptlp-package-list > .fptlp-package-editor');
    $(panel).find('.fptlp-package-count').text('(' + cards.length + ' gói)');
    $(panel).find('.fptlp-empty-group').prop('hidden', cards.length !== 0);
    $(panel).find('.fptlp-limit-note').prop('hidden', cards.length <= 6);
    cards.each(function (i) {
      $(this).find('.fptlp-move-up').prop('disabled', i === 0);
      $(this).find('.fptlp-move-down').prop('disabled', i === cards.length - 1);
    });
  }
  function imageGuidance(image) {
    var container = image.closest('.fptlp-package-image');
    if (!container) return;
    var note = container.querySelector('.fptlp-image-guidance');
    if (!note) return;
    if (!image.getAttribute('src') || !image.naturalWidth) { note.textContent = ''; return; }
    var ratio = image.naturalWidth / image.naturalHeight;
    var matches = Math.abs(ratio - 62 / 45) < 0.03;
    note.textContent = image.naturalWidth + ' × ' + image.naturalHeight + ' px. ' +
      (matches ? 'Tỷ lệ phù hợp với khung gói cước.' : 'Ảnh khác tỷ lệ khung: sẽ có khoảng trắng để giữ đầy đủ nội dung. Nên chuẩn bị ảnh 1240 × 900 px.');
    note.classList.toggle('fptlp-image-guidance-warning', !matches);
  }
  root.addEventListener('load', function (event) {
    if (event.target.matches('.fptlp-package-image img')) imageGuidance(event.target);
  }, true);
  root.querySelectorAll('.fptlp-package-image img').forEach(function (image) { if (image.complete) imageGuidance(image); });
  function preview(field, url) {
    field.find('.fptlp-image-value').val(url).trigger('change');
    var img = field.find('img');
    if (url) img.attr('src', url); else img.removeAttr('src');
    img.prop('hidden', !url);
    if (!url) imageGuidance(img[0]);
    field.find('.fptlp-image-empty').prop('hidden', !!url);
    field.find('.fptlp-remove-image').prop('hidden', !url);
    field.find('.fptlp-pick-image').text(url ? 'Đổi ảnh' : 'Chọn ảnh');
  }
  function updateContentList(section) {
    var rows=section.querySelectorAll('.fptlp-content-list > .fptlp-content-row');
    section.querySelector('.fptlp-content-add').disabled=rows.length>=Number(section.dataset.limit);
    rows.forEach(function(row,index) {
      row.querySelector('.fptlp-content-up').disabled=index===0;
      row.querySelector('.fptlp-content-down').disabled=index===rows.length-1;
    });
  }
  root.querySelectorAll('.fptlp-content-list-editor').forEach(updateContentList);
  $(root).on('click','.fptlp-content-add',function () {
    var section=this.closest('.fptlp-content-list-editor');
    if(section.querySelectorAll('.fptlp-content-list > .fptlp-content-row').length>=Number(section.dataset.limit))return;
    var html=section.querySelector('template').innerHTML.replace(/__CONTENT_ROW__/g,'new_'+(++counter));
    var row=$(html).appendTo(section.querySelector('.fptlp-content-list'));
    updateContentList(section);changed();row.find('input[type="text"]').first().trigger('focus');
    announce('Đã thêm dòng nội dung.');
  }).on('click','.fptlp-content-remove',function () {
    var section=this.closest('.fptlp-content-list-editor');
    this.closest('.fptlp-content-row').remove();updateContentList(section);changed();
    section.querySelector('.fptlp-content-add').focus();announce('Đã xóa dòng nội dung. Bấm Lưu để áp dụng.');
  }).on('click','.fptlp-content-up,.fptlp-content-down',function () {
    var row=$(this).closest('.fptlp-content-row'),section=this.closest('.fptlp-content-list-editor');
    if($(this).hasClass('fptlp-content-up'))row.prev().before(row);else row.next().after(row);
    updateContentList(section);changed();this.focus();announce('Đã đổi thứ tự nội dung.');
  });
  $(root).on('click', '.fptlp-pick-image', function (event) {
    event.preventDefault();
    if (!window.wp || typeof window.wp.media !== 'function') {
      window.alert('Thư viện ảnh WordPress chưa tải được. Vui lòng tải lại trang quản trị và thử lại.');
      return;
    }
    mediaField = $(this).closest('.fptlp-image-field');
    if (!mediaFrame) {
      mediaFrame = wp.media({title: 'Chọn hình ảnh', button: {text: 'Dùng ảnh này'}, multiple: false, library: {type: 'image'}});
      // WordPress activates the default state while rendering the modal on open.
      // Reading state().get(...) before that first open throws and prevents the dialog.
      mediaFrame.on('open', function () {
        var state = mediaFrame.state();
        var selection = state && state.get('selection');
        if (selection) selection.reset();
      });
      mediaFrame.on('select', function () {
        var state = mediaFrame.state();
        var selection = state && state.get('selection');
        var selected = selection && selection.first();
        if (!selected || !mediaField || !root.contains(mediaField[0])) return;
        var item = selected.toJSON();
        if (item.url) preview(mediaField, item.url);
      });
    }
    mediaFrame.open();
  }).on('click', '.fptlp-add-equipment, .fptlp-add-region', function () {
    var section = $(this).closest('.fptlp-editor-section');
    var equipment = $(this).hasClass('fptlp-add-equipment');
    var type = equipment ? 'equipment' : 'region';
    var template = section.find('template')[0];
    var row = $(template.innerHTML.replace(/__ROW__/g, 'new_' + (++counter)));
    row.appendTo(section.find('.fptlp-' + type + '-list')).find('input[type="text"]').first().trigger('focus');
    changed();
  }).on('click', '.fptlp-remove-equipment, .fptlp-remove-region', function () {
    var section = $(this).closest('.fptlp-editor-section');
    $(this).closest('.fptlp-equipment-row, .fptlp-region-row').remove();
    rowMoves(section.closest('.fptlp-package-editor')[0]);
    section.find('.fptlp-add-equipment, .fptlp-add-region').trigger('focus'); changed();
  }).on('click', '.fptlp-remove-image', function () {
    preview($(this).closest('.fptlp-image-field'), '');
  }).on('click', '.fptlp-admin-tab', function () {
    show(this.dataset.adminTab);
  }).on('click', '.fptlp-add-package', function () {
    var panel = this.closest('.fptlp-admin-category');
    var html = panel.querySelector('.fptlp-package-template').innerHTML.replace(/__INDEX__/g, 'new_' + (++counter));
    var card = $(html).appendTo($(panel).find('.fptlp-package-list'));
    groupCard(card[0]);card[0].open=true;
    update(panel); changed();
    card.find('[data-field="name"]').trigger('focus');
    announce('Đã thêm gói cước mới.');
  }).on('click', '.fptlp-remove-package', function () {
    var card = this.closest('.fptlp-package-editor');
    if (!window.confirm('Xóa gói “' + card.querySelector('[data-field="name"]').value + '”? Bấm Lưu để áp dụng.')) return;
    var panel = card.closest('.fptlp-admin-category');
    card.remove(); update(panel); changed();
    $(panel).find('.fptlp-add-package').trigger('focus');
    announce('Đã xóa gói cước khỏi danh sách đang sửa.');
  }).on('click', '.fptlp-move-up, .fptlp-move-down', function () {
    var card = $(this).closest('.fptlp-package-editor');
    if ($(this).hasClass('fptlp-move-up')) card.prev().before(card); else card.next().after(card);
    update(card.closest('.fptlp-admin-category')[0]); changed(); this.focus();
    announce('Đã đổi thứ tự gói cước.');
  }).on('click', '.fptlp-add-benefit', function () {
    var fieldset = $(this).closest('fieldset');
    var name = $(this).closest('.fptlp-package-editor').find('[data-field="name"]').attr('name').replace(/\[name\]$/, '[benefits][]');
    var row = $('<div class="fptlp-benefit-row">');
    $('<input type="text" aria-label="Quyền lợi" placeholder="Nhập quyền lợi">').attr('name', name).appendTo(row);
    $('<button type="button" class="button fptlp-remove-benefit" aria-label="Xóa quyền lợi">×</button>').appendTo(row);
    row.appendTo(fieldset.find('.fptlp-benefit-list')).find('input').trigger('focus'); changed();
  }).on('click', '.fptlp-remove-benefit', function () {
    var fieldset = $(this).closest('fieldset');
    $(this).closest('.fptlp-benefit-row').remove(); rowMoves(fieldset.closest('.fptlp-package-editor')[0]);changed();
    fieldset.find('.fptlp-add-benefit').trigger('focus');
  }).on('input', '[data-field="name"]', function () {
    $(this).closest('.fptlp-package-editor').find('.fptlp-package-title').text(this.value || 'Gói cước mới');
  }).on('input change', 'input, textarea, select', function () {
    $(this).closest('.fptlp-region-row, .fptlp-equipment-row').find('input[type="text"]').each(function () { this.setCustomValidity(''); });
    changed();
  });
  function revealField(field) {
    var panel=field.closest('.fptlp-admin-category');
    if(panel) show(panel.dataset.adminPanel);
    var ancestor=field.parentElement;
    while(ancestor && ancestor!==root){if(ancestor.tagName==='DETAILS')ancestor.open=true;ancestor=ancestor.parentElement;}
  }
  function cardSummary(card){
    var title=card.querySelector('.fptlp-package-title');
    title.textContent=card.querySelector('[data-field="name"]').value || 'Gói cước mới';
    var price=card.querySelector('.fptlp-package-summary-price');
    if(!price){price=document.createElement('span');price.className='fptlp-package-summary-price';title.after(price);}
    price.textContent=card.querySelector('[data-field="price"]').value || 'Chưa nhập giá';
  }
  function rowMoves(card){
    ['.fptlp-benefit-list','.fptlp-equipment-list'].forEach(function(selector){
      var list=card.querySelector(selector);if(!list)return;
      Array.from(list.children).forEach(function(row,index){
        var controls=row.querySelector('.fptlp-row-moves');
        if(!controls){
          controls=document.createElement('span');controls.className='fptlp-row-moves';
          [['up','↑','Chuyển dòng lên'],['down','↓','Chuyển dòng xuống']].forEach(function(data){
            var button=document.createElement('button');button.type='button';button.className='button fptlp-row-'+data[0];button.textContent=data[1];button.setAttribute('aria-label',data[2]);controls.appendChild(button);
          });row.appendChild(controls);
        }
        controls.querySelector('.fptlp-row-up').disabled=index===0;
        controls.querySelector('.fptlp-row-down').disabled=index===list.children.length-1;
      });
    });
  }
  function groupCard(card){
    if(card.dataset.grouped)return;card.dataset.grouped='1';
    var body=card.querySelector('.fptlp-package-body'),layout=body.querySelector('.fptlp-package-layout');
    function group(label,open){
      var details=document.createElement('details');details.className='fptlp-editor-group';details.open=!!open;
      var summary=document.createElement('summary');summary.textContent=label;details.appendChild(summary);
      var fields=document.createElement('div');fields.className='fptlp-group-fields';details.appendChild(fields);body.appendChild(details);return fields;
    }
    function moveField(field,target){target.appendChild(card.querySelector('[data-field="'+field+'"]').closest('label'));}
    var basic=group('Thông tin cơ bản',true);basic.classList.add('fptlp-fields-grid');
    ['name','price','download','upload'].forEach(function(f){moveField(f,basic);});
    var images=group('Ảnh và nhãn nổi bật');images.classList.add('fptlp-fields-grid');
    moveField('badge',images);moveField('meter_level',images);
    images.appendChild(card.querySelector('.fptlp-badge-help'));images.appendChild(card.querySelector('.fptlp-package-image'));
    var benefits=group('Quyền lợi và thiết bị');benefits.appendChild(card.querySelector('fieldset.fptlp-benefits'));
    benefits.appendChild(card.querySelector('.fptlp-equipment-list').closest('.fptlp-editor-section'));
    var regions=group('Giá theo khu vực');regions.appendChild(card.querySelector('.fptlp-region-list').closest('.fptlp-editor-section'));
    var links=group('Liên kết bài viết');moveField('detail',links);
    var help=document.createElement('p');help.className='description';help.textContent='Dán đường dẫn bài viết WordPress. Khách mở qua Xem nhanh → Xem trang chi tiết.';links.appendChild(help);
    layout.remove();cardSummary(card);rowMoves(card);
  }
  root.querySelectorAll('.fptlp-package-list').forEach(function(list){
    Array.from(list.children).forEach(function(card,index){groupCard(card);card.open=index===0;});
  });
  $(root).on('input','[data-field="name"],[data-field="price"]',function(){cardSummary(this.closest('.fptlp-package-editor'));});
  $(root).on('click','.fptlp-row-up,.fptlp-row-down',function(){
    var row=this.closest('.fptlp-benefit-row,.fptlp-equipment-row'),card=row.closest('.fptlp-package-editor');
    if(this.classList.contains('fptlp-row-up')){if(row.previousElementSibling)row.previousElementSibling.before(row);}
    else if(row.nextElementSibling)row.nextElementSibling.after(row);
    rowMoves(card);changed();this.focus();announce('Đã đổi thứ tự dòng. Bấm Lưu để áp dụng.');
  });
  $(root).on('click','.fptlp-add-equipment,.fptlp-remove-equipment,.fptlp-add-benefit,.fptlp-remove-benefit',function(){var card=this.closest('.fptlp-package-editor');if(card)rowMoves(card);});

  $(root).find('.fptlp-admin-category').each(function () { update(this); });
  if (root.querySelector('.fptlp-admin-tab')) show($('#fptlp_first_group').val() || root.querySelector('.fptlp-admin-tab').dataset.adminTab);
  // Validate only the first invalid field, so later hidden tabs cannot steal focus.
  if (form) {
    form.addEventListener('invalid', function (event) {
      var panel = event.target.closest('.fptlp-admin-category');
      var card = event.target.closest('details');
      if (panel) show(panel.dataset.adminPanel);
      revealField(event.target);
    }, true);
    form.noValidate = true;
    form.addEventListener('submit', function (event) {
      $(root).find('.fptlp-region-row').each(function () {
        var inputs = this.querySelectorAll('input[type="text"]');
        var label = inputs[0].value.trim(), price = inputs[1].value.trim();
        inputs[0].setCustomValidity(price && !label ? 'Vui lòng nhập tên khu vực.' : '');
        inputs[1].setCustomValidity(label && !price ? 'Vui lòng nhập giá tại khu vực này.' : '');
      });
      $(root).find('.fptlp-equipment-row').each(function () {
        var title = this.querySelector('input[type="text"]');
        var image = this.querySelector('.fptlp-image-value');
        title.setCustomValidity(image.value && !title.value.trim() ? 'Vui lòng nhập tên thiết bị.' : '');
      });
      var invalid = Array.prototype.find.call(form.elements, function (field) {
        return field.willValidate && !field.validity.valid;
      });
      if (invalid) {
        event.preventDefault();
        var panel = invalid.closest('.fptlp-admin-category');
        var card = invalid.closest('details');
        if (panel) show(panel.dataset.adminPanel);
        revealField(invalid);
        invalid.focus();
        invalid.reportValidity();
        return;
      }
      dirty = false;
    });
  }
  window.addEventListener('beforeunload', function (event) {
    if (!dirty) return;
    event.preventDefault(); event.returnValue = '';
  });
});
