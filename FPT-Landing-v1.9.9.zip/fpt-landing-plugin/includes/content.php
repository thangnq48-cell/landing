<?php
if (!defined('ABSPATH')) exit;

/** Editable landing-page content, separate from package records and registration. */
trait FPTLP_Content {
    private function content_defaults() {
        return [
            'info'=>['enabled'=>'1','title'=>'Internet FPT – kết nối cho gia đình và công việc','intro'=>'Chọn gói Internet theo số thiết bị, nhu cầu học tập, làm việc và giải trí. Giá, thiết bị và ưu đãi được xác nhận theo địa chỉ lắp đặt.', 'cards'=>[
                ['title'=>'Kết nối theo nhu cầu','body'=>'Lựa chọn tốc độ và thiết bị Wi-Fi phù hợp với không gian sử dụng.','image'=>'','tone'=>'orange'],
                ['title'=>'Internet & FPT Play','body'=>'Kết hợp đường truyền Internet và truyền hình trong các gói Combo.','image'=>'','tone'=>'blue'],
                ['title'=>'Ưu đãi theo khu vực','body'=>'Kiểm tra giá, quà tặng và điều kiện áp dụng trước khi đăng ký.','image'=>'','tone'=>'green'],
            ]],
            'business'=>['title'=>'Internet FPT cho doanh nghiệp','intro'=>'Giải pháp kết nối cho văn phòng, cửa hàng và cơ sở kinh doanh. Chọn gói theo số người dùng, ứng dụng và yêu cầu vận hành.'],
            'article'=>['enabled'=>'1','title'=>'Lắp mạng Internet FPT: chọn gói phù hợp, đăng ký và chi phí hòa mạng',
                'intro'=>'Khi đăng ký Internet FPT, bạn nên cân nhắc đồng thời tốc độ, vùng phủ Wi-Fi, thiết bị đi kèm và tổng chi phí sử dụng. Một gói phù hợp cần đáp ứng việc học, làm việc hoặc kinh doanh, đồng thời có mức cước rõ ràng theo địa chỉ lắp đặt.',
                'sections'=>[
                    ['heading'=>'Vì sao lựa chọn Internet FPT?','body'=>"Internet FPT có các lựa chọn cho cá nhân, gia đình và doanh nghiệp. Bạn có thể chọn gói Internet riêng hoặc gói Combo kết hợp truyền hình FPT Play, tùy nhu cầu và dịch vụ được cung cấp tại khu vực.\n\nVới gia đình sử dụng nhiều điện thoại, máy tính và TV, ngoài tốc độ đường truyền, vị trí đặt modem và vùng phủ Wi-Fi cũng rất quan trọng. Khi cần mở rộng kết nối đến nhiều phòng hoặc tầng, hãy trao đổi về thiết bị Mesh và chi phí bổ sung trước khi chốt phương án."],
                    ['heading'=>'Nên chọn gói Giga, Sky, Meta hay gói doanh nghiệp?','body'=>"Hãy bắt đầu từ số thiết bị dùng đồng thời và các hoạt động thường xuyên: học trực tuyến, họp video, xem phim hoặc tải dữ liệu. Đối chiếu tốc độ tải xuống, tải lên, thiết bị và quyền lợi trong từng thẻ gói; thông số có thể khác giữa gói Internet và gói Combo.\n\nVăn phòng hoặc cửa hàng nên trao đổi thêm về số nhân sự, camera, phần mềm quản lý và yêu cầu kết nối. Nếu cần địa chỉ IP hoặc cam kết dịch vụ riêng, hãy yêu cầu tư vấn xác nhận rõ trong báo giá. Tốc độ trải nghiệm thực tế còn phụ thuộc thiết bị, kết nối Wi-Fi và dịch vụ đang truy cập."],
                    ['heading'=>'Quy trình đăng ký lắp mạng FPT','body'=>"Bước 1: Chọn gói quan tâm và gửi số điện thoại, địa chỉ lắp đặt qua biểu mẫu tư vấn.\n\nBước 2: Nhân viên kiểm tra khả năng cung cấp dịch vụ, tư vấn gói và xác nhận giá, phí hòa mạng, thiết bị cùng ưu đãi áp dụng.\n\nBước 3: Thống nhất thông tin hợp đồng, giấy tờ cần cung cấp và lịch triển khai. Hồ sơ có thể khác nhau giữa khách hàng cá nhân và doanh nghiệp.\n\nBước 4: Kỹ thuật triển khai theo lịch đã xác nhận. Trước khi nghiệm thu, kiểm tra kết nối ở các vị trí thường sử dụng và lưu lại thông tin hợp đồng, thanh toán, hỗ trợ."],
                    ['heading'=>'Những thông tin cần xác nhận trước khi lắp đặt','body'=>"Ngoài cước hằng tháng, hãy hỏi rõ khoản thanh toán ban đầu, thời hạn trả trước, thuế nếu có, thiết bị được bàn giao và điều kiện hưởng ưu đãi. Các nhu cầu như thêm FPT Play Box, mở rộng Wi-Fi hoặc thay đổi vị trí lắp đặt cần được báo giá riêng khi phát sinh.\n\nThời gian triển khai phụ thuộc hạ tầng và lịch kỹ thuật tại địa chỉ đăng ký. Hãy xác nhận lịch hẹn cụ thể; không nên mặc định mọi địa chỉ đều có cùng thời gian lắp đặt. Bạn có thể dùng nút Đăng ký ngay trên gói cước để gửi yêu cầu tư vấn phù hợp."],
                ],
                'fee_title'=>'Phí hòa mạng Internet FPT tham khảo','fee_note'=>'Các mức dưới đây là giá tham khảo, không phải báo giá áp dụng cho mọi địa chỉ. Mức phí chính thức, thuế, thiết bị và ưu đãi cần được xác nhận theo khu vực, gói cước và thời điểm đăng ký.',
                'fees'=>[
                    ['label'=>'Internet cá nhân – gia đình','amount'=>'Từ 299.000đ','note'=>'Xác nhận mức áp dụng tại địa chỉ lắp đặt.'],
                    ['label'=>'Combo truyền hình','amount'=>'299.000đ – 499.000đ','note'=>'Tùy gói Fx và điều kiện áp dụng.'],
                    ['label'=>'Internet doanh nghiệp','amount'=>'500.000đ – 2.500.000đ','note'=>'Tùy gói và số tháng trả trước.'],
                ]],
            'price_table'=>['enabled'=>'1','title'=>'Bảng giá Internet FPT tham khảo','intro'=>'Giá cước theo tháng, mang tính tham khảo; giá và thiết bị áp dụng cần được xác nhận theo khu vực, thời điểm đăng ký.',
                'column_name'=>'Gói cước','column_price'=>'Giá cước (chỉ từ)','column_register'=>'Đăng ký','column_equipment'=>'Thiết bị, dịch vụ đi kèm','button_label'=>'Đăng ký',
                'plans'=>[
                    ['name'=>'Giga (300 Mbps)','price'=>'195.000đ','equipment'=>'Modem Wi-Fi 6'],
                    ['name'=>'Sky (1 Gbps – 300 Mbps)','price'=>'195.000đ','equipment'=>'Modem Wi-Fi 6'],
                    ['name'=>'Giga F1 (300 Mbps)','price'=>'205.000đ','equipment'=>'Modem Wi-Fi 6, Access Point'],
                    ['name'=>'Sky F1 (1 Gbps – 300 Mbps)','price'=>'210.000đ','equipment'=>'Modem Wi-Fi 6, Access Point'],
                    ['name'=>'Giga F2 (300 Mbps)','price'=>'225.000đ','equipment'=>'Modem Wi-Fi 6, 2 Access Point'],
                    ['name'=>'Sky F2 (1 Gbps – 300 Mbps)','price'=>'230.000đ','equipment'=>'Modem Wi-Fi 6, 2 Access Point'],
                ]],
            'faq'=>['enabled'=>'1','title'=>'Câu hỏi thường gặp','items'=>[
                ['question'=>'Giá Internet FPT từ 195.000đ/tháng có áp dụng cho mọi khu vực không?','answer'=>'Không nên mặc định mức giá này áp dụng cho mọi địa chỉ. Giá và điều kiện có thể thay đổi theo khu vực, gói cước và thời điểm. Hãy cung cấp địa chỉ để được xác nhận mức cước trước khi đăng ký.'],
                ['question'=>'Khi đăng ký Internet FPT hiện có những khuyến mãi nào?','answer'=>'Ưu đãi phụ thuộc chương trình tại khu vực và điều kiện của từng gói. Bạn nên hỏi rõ quyền lợi về thiết bị, tháng cước, truyền hình hoặc quà tặng, thời hạn áp dụng và điều kiện trả trước. Nội dung được tư vấn cần được xác nhận trước khi ký hợp đồng.'],
                ['question'=>'Quy trình và thủ tục đăng ký Internet FPT có phức tạp không?','answer'=>'Bạn gửi thông tin liên hệ và địa chỉ, nhận tư vấn và báo giá, sau đó thống nhất hồ sơ, hợp đồng và lịch lắp đặt. Nhân viên sẽ hướng dẫn giấy tờ phù hợp với khách hàng cá nhân hoặc doanh nghiệp.'],
                ['question'=>'Gói Giga, Sky và Meta khác nhau như thế nào?','answer'=>'Các gói có thể khác về tốc độ tải xuống/tải lên, thiết bị, quyền lợi và giá. Hãy xem thông số trong thẻ gói và phần Xem nhanh, đồng thời phân biệt gói Internet với gói Combo cùng tên để chọn đúng nhu cầu.'],
                ['question'=>'Bao lâu sau khi đăng ký thì FPT đến triển khai?','answer'=>'Lịch triển khai phụ thuộc hạ tầng, địa chỉ và lịch kỹ thuật. Sau khi kiểm tra khả năng cung cấp dịch vụ, nhân viên sẽ xác nhận thời gian hẹn cụ thể với bạn.'],
                ['question'=>'Tôi có thể đăng ký Internet FPT online mà không cần ra cửa hàng không?','answer'=>'Bạn có thể gửi yêu cầu tư vấn trực tuyến qua biểu mẫu trên trang. Nhân viên sẽ liên hệ hướng dẫn bước tiếp theo và xác nhận cách hoàn tất hồ sơ, hợp đồng phù hợp với trường hợp của bạn.'],
            ]],
        ];
    }
    private function content_settings($settings) {
        $result=$this->content_defaults();
        foreach ($result as $key=>$defaults) {
            if (isset($settings['landing_content'][$key]) && is_array($settings['landing_content'][$key])) $result[$key]=array_merge($defaults,array_intersect_key($settings['landing_content'][$key],$defaults));
        }
        return $result;
    }
    private function content_row_schema($kind) {
        return [
            'cards'=>['title'=>'Tiêu đề','body'=>'Mô tả ngắn','image'=>'Ảnh minh họa','tone'=>'Màu nền'],
            'sections'=>['heading'=>'Tiêu đề đoạn','body'=>'Nội dung đoạn'],
            'fees'=>['label'=>'Nhóm dịch vụ','amount'=>'Phí tham khảo','note'=>'Ghi chú'],
            'items'=>['question'=>'Câu hỏi','answer'=>'Câu trả lời'],
            'plans'=>['name'=>'Tên gói và tốc độ','price'=>'Giá cước / tháng','equipment'=>'Thiết bị, dịch vụ đi kèm'],
        ][$kind] ?? [];
    }
    private function sanitize_content($input, $out) {
        $current=$this->content_settings($out);$defaults=$this->content_defaults();
        // WordPress can sanitize the normalized settings again while creating an option.
        $normalized=isset($input['landing_content']) && is_array($input['landing_content']) ? $input['landing_content'] : [];
        $submitted=isset($input['content_sections']) && is_array($input['content_sections']) ? $input['content_sections'] : [];
        foreach ($defaults as $key=>$definition) {
            if (array_key_exists($key,$submitted)) {
                if (empty($input['content_complete'][$key])) { add_settings_error(self::OPT,'content-incomplete-'.$key,'Chưa lưu nội dung vì biểu mẫu chưa đầy đủ. Nội dung cũ được giữ lại.','error');continue; }
                $section=$submitted[$key];
            } elseif (array_key_exists($key,$normalized)) $section=$normalized[$key]; else continue;
            if (!is_array($section)) continue;
            $clean=$current[$key];$valid=true;
            foreach ($definition as $field=>$default) {
                if (is_array($default)) {
                    $rows=$section[$field] ?? [];
                    if (!is_array($rows)) { $valid=false;break; }
                    $limit=['cards'=>6,'sections'=>12,'fees'=>12,'items'=>30,'plans'=>30][$field];
                    if (count($rows)>$limit) { $valid=false;break; }
                    $clean[$field]=[];
                    foreach ($rows as $row) {
                        if (!is_array($row)) { $valid=false;break; }
                        $item=[];
                        foreach ($this->content_row_schema($field) as $column=>$label) {
                            $value=$row[$column] ?? '';
                            if (!is_scalar($value)) { $valid=false;break; }
                            if ($column==='image') $item[$column]=esc_url_raw($value);
                            elseif ($column==='tone') $item[$column]=in_array($value,['orange','blue','green'],true)?$value:'blue';
                            elseif (in_array($column,['body','answer'],true)) $item[$column]=sanitize_textarea_field($value);
                            else $item[$column]=sanitize_text_field($value);
                        }
                        if (!$valid) break;
                        $primary=['cards'=>'title','sections'=>'heading','fees'=>'label','items'=>'question','plans'=>'name'][$field];
                        $content=array_filter($item,static function($v,$k){return $k!=='tone' && $v!=='';},ARRAY_FILTER_USE_BOTH);
                        if (!$content) continue;
                        if ($item[$primary]==='' || ($field==='items' && $item['answer']==='') || ($field==='fees' && $item['amount']==='') || ($field==='plans' && $item['price']==='')) { $valid=false;break; }
                        $clean[$field][]=$item;
                    }
                } else {
                    $value=$section[$field] ?? $default;
                    if (!is_scalar($value)) { $valid=false;break; }
                    $clean[$field]=$field==='enabled' ? ((string)$value==='1'?'1':'0') : (in_array($field,['intro','fee_note'],true)?sanitize_textarea_field($value):sanitize_text_field($value));
                }
            }
            if ($valid) $current[$key]=$clean;
            else add_settings_error(self::OPT,'content-invalid-'.$key,'Chưa lưu mục nội dung: hãy kiểm tra các dòng thiếu tiêu đề, câu trả lời hoặc mức phí. Nội dung cũ được giữ lại.','error');
        }
        $out['landing_content']=$current;
        return $out;
    }
    private function content_menus() {
        foreach ([['Giới thiệu Internet','fptlp-info','info_page'],['Gói doanh nghiệp','fptlp-business','business_page'],['Bài viết Internet FPT','fptlp-article','article_page'],['Câu hỏi thường gặp','fptlp-faq','faq_page'],['Bảng giá tổng hợp','fptlp-price-table','price_table_page']] as $menu) {
            $this->admin_page_hooks[]=add_submenu_page('fptlp',$menu[0],$menu[0],'manage_options',$menu[1],[$this,$menu[2]]);
        }
    }
    public function info_page() { $this->content_page('info','Giới thiệu Internet'); }
    public function article_page() { $this->content_page('article','Bài viết Internet FPT'); }
    public function faq_page() { $this->content_page('faq','Câu hỏi thường gặp'); }
    public function price_table_page() { $this->content_page('price_table','Bảng giá tổng hợp'); }
    public function business_page() { $this->packages_page(true); }
    private function content_input($name,$label,$value,$textarea=false,$required=false) { ?>
        <label class="fptlp-field"><span><?php echo esc_html($label); ?></span><?php if ($textarea): ?><textarea name="<?php echo esc_attr($name); ?>" rows="4" <?php if($required) echo 'required'; ?>><?php echo esc_textarea($value); ?></textarea><?php else: ?><input type="text" name="<?php echo esc_attr($name); ?>" value="<?php echo esc_attr($value); ?>" <?php if($required) echo 'required'; ?>><?php endif; ?></label>
        <?php
    }
    private function business_admin_fields($settings) {
        $section=$this->content_settings($settings)['business'];$base=self::OPT.'[content_sections][business]'; ?>
        <div class="fptlp-content-editor"><p>Nhóm này hiển thị riêng bên dưới phần giới thiệu Internet, không nằm trong thanh tab phía trên.</p>
        <?php $this->content_input($base.'[title]','Tiêu đề khu vực doanh nghiệp',$section['title']);$this->content_input($base.'[intro]','Giới thiệu ngắn',$section['intro'],true); ?></div>
        <?php
    }
    private function content_row($section,$kind,$index,$item=[]) {
        $base=self::OPT.'[content_sections]['.$section.']['.$kind.']['.$index.']'; ?>
        <div class="fptlp-content-row">
            <div class="fptlp-content-row-tools"><button type="button" class="button fptlp-content-up" aria-label="Chuyển dòng lên">↑ Lên</button><button type="button" class="button fptlp-content-down" aria-label="Chuyển dòng xuống">↓ Xuống</button><button type="button" class="button-link-delete fptlp-content-remove">Xóa dòng</button></div>
            <?php foreach ($this->content_row_schema($kind) as $field=>$label):
                if ($field==='image') { $this->image_field($base.'[image]',$item['image'] ?? '','Ảnh thẻ giới thiệu');continue; }
                if ($field==='tone'): ?>
                    <label class="fptlp-field"><span>Màu nền</span><select name="<?php echo esc_attr($base.'[tone]'); ?>"><?php foreach (['orange'=>'Cam','blue'=>'Xanh dương','green'=>'Xanh lá'] as $value=>$title): ?><option value="<?php echo esc_attr($value); ?>" <?php selected($item['tone'] ?? 'blue',$value); ?>><?php echo esc_html($title); ?></option><?php endforeach; ?></select></label>
                <?php else: $this->content_input($base.'['.$field.']',$label,$item[$field] ?? '',in_array($field,['body','answer'],true),in_array($field,['title','heading','label','amount','question','answer','name','price'],true));endif;
            endforeach; ?>
        </div><?php
    }
    private function content_list($section,$kind,$title,$rows,$limit) { ?>
        <section class="fptlp-content-list-editor" data-limit="<?php echo (int)$limit; ?>"><h2><?php echo esc_html($title); ?></h2>
            <div class="fptlp-content-list"><?php foreach ($rows as $index=>$row) $this->content_row($section,$kind,$index,$row); ?></div>
            <button type="button" class="button fptlp-content-add">+ Thêm dòng</button><span class="description"> Tối đa <?php echo (int)$limit; ?> dòng.</span>
            <template><?php $this->content_row($section,$kind,'__CONTENT_ROW__'); ?></template>
        </section><?php
    }
    private function content_page($key,$title) {
        if (!$this->admin_start($title)) return;
        $section=$this->content_settings($this->settings())[$key];$base=self::OPT.'[content_sections]['.$key.']'; ?>
        <div class="fptlp-content-editor">
        <input type="hidden" name="<?php echo esc_attr($base.'[enabled]'); ?>" value="0"><label><input type="checkbox" name="<?php echo esc_attr($base.'[enabled]'); ?>" value="1" <?php if($section['enabled']==='1') echo 'checked'; ?>> Hiển thị mục này trên landing page</label>
        <?php $this->content_input($base.'[title]','Tiêu đề',$section['title']);
        if (isset($section['intro'])) $this->content_input($base.'[intro]','Đoạn giới thiệu luôn hiển thị',$section['intro'],true);
        if ($key==='info') { ?><p class="description">Ba thẻ ngắn nằm giữa gói cá nhân và gói doanh nghiệp. Ảnh minh họa là tùy chọn; tiêu đề và mô tả vẫn là chữ có thể chỉnh sửa.</p><?php $this->content_list($key,'cards','Các thẻ giới thiệu',$section['cards'],6); }
        if ($key==='article') {
            ?><p class="description">Bài viết có nút Xem thêm/Thu gọn. Mỗi đoạn gồm tiêu đề và nội dung riêng; cách một dòng trống để tách đoạn văn. Không cần nhập mã HTML.</p><?php
            $this->content_list($key,'sections','Các phần của bài viết',$section['sections'],12);
            $this->content_input($base.'[fee_title]','Tiêu đề phần phí hòa mạng',$section['fee_title']);
            $this->content_input($base.'[fee_note]','Ghi chú về giá tham khảo',$section['fee_note'],true);
            $this->content_list($key,'fees','Các mức phí tham khảo',$section['fees'],12);
        }
        if ($key==='price_table') {
            ?><p class="description">Bảng nằm dưới bài viết, trước Câu hỏi thường gặp và vẫn hiện khi thu gọn bài viết. Nội dung khởi tạo theo ảnh mẫu; đây là bảng nhập riêng, không tự đồng bộ giá với thẻ gói cước hoặc khu vực. Hãy cập nhật giá, thiết bị và ghi chú trước khi sử dụng.</p><?php
            foreach (['column_name'=>'Tiêu đề cột gói cước','column_price'=>'Tiêu đề cột giá','column_register'=>'Tiêu đề cột đăng ký','column_equipment'=>'Tiêu đề cột thiết bị','button_label'=>'Chữ trên nút đăng ký'] as $field=>$label) $this->content_input($base.'['.$field.']',$label,$section[$field]);
            $this->content_list($key,'plans','Các dòng gói cước',$section['plans'],30);
        }
        if ($key==='faq') { ?><p class="description">Mỗi câu hỏi đóng/mở độc lập. Bạn có thể thêm, xóa hoặc đổi thứ tự.</p><?php $this->content_list($key,'items','Danh sách câu hỏi',$section['items'],30); } ?>
        </div><input type="hidden" name="<?php echo esc_attr(self::OPT.'[content_complete]['.$key.']'); ?>" value="1">
        <?php submit_button('Lưu nội dung'); ?><p class="fptlp-admin-status screen-reader-text" aria-live="polite"></p></form></div><?php
    }
    private function content_paragraphs($text) {
        foreach (preg_split('/\r?\n\s*\r?\n/u',trim($text)) as $paragraph) if ($paragraph!=='') echo '<p>'.nl2br(esc_html($paragraph)).'</p>';
    }
    private function render_info($settings) {
        $c=$this->content_settings($settings)['info'];if($c['enabled']!=='1')return; ?>
        <section class="fptlp-content-section fptlp-info" aria-label="Giới thiệu Internet FPT"><header class="fptlp-content-heading"><h2><?php echo esc_html($c['title']); ?></h2><?php $this->content_paragraphs($c['intro']); ?></header>
        <?php if($c['cards']): ?><div class="fptlp-info-grid"><?php foreach($c['cards'] as $i=>$card): ?>
            <article class="fptlp-info-card fptlp-info-<?php echo esc_attr($card['tone']); ?>"><div class="fptlp-info-copy"><h3><?php echo esc_html($card['title']); ?></h3><p><?php echo esc_html($card['body']); ?></p></div>
            <?php if($card['image']): ?><img src="<?php echo esc_url($card['image']); ?>" alt="" loading="lazy" decoding="async" width="160" height="160"><?php else: ?><svg class="fptlp-info-icon" viewBox="0 0 80 80" aria-hidden="true"><circle cx="40" cy="40" r="35" fill="none" stroke="currentColor" opacity=".2"/><?php if($i%3===0): ?><path d="M18 34Q40 14 62 34M26 44Q40 31 54 44M34 54Q40 48 46 54" fill="none" stroke="currentColor" stroke-width="5" stroke-linecap="round"/><circle cx="40" cy="63" r="3" fill="currentColor"/><?php elseif($i%3===1): ?><rect x="15" y="22" width="50" height="36" rx="7" fill="none" stroke="currentColor" stroke-width="4"/><path d="M34 31L49 40L34 49Z" fill="currentColor"/><?php else: ?><path d="M20 35H60V61H20ZM16 27H64V36H16ZM40 27V61" fill="none" stroke="currentColor" stroke-width="4" stroke-linejoin="round"/><path d="M40 27C15 28 24 7 40 27C56 7 65 28 40 27" fill="none" stroke="currentColor" stroke-width="4"/><?php endif; ?></svg><?php endif; ?></article>
        <?php endforeach; ?></div><?php endif; ?></section><?php
    }
    private function render_business($settings,$groups,$uid) {
        $c=$this->content_settings($settings)['business'];$info=$this->package_categories()['business'];$items=array_slice($this->parse_packages($groups['business'] ?? ''),0,6);
        if ($settings['hide_empty_categories']==='1' && !$items) return; ?>
        <section class="fptlp-packages fptlp-business" aria-labelledby="<?php echo esc_attr($uid.'-business-heading'); ?>"><div class="fptlp-tab-panel" data-fptlp-category="business">
            <header class="fptlp-content-heading fptlp-business-heading"><span class="fptlp-business-label">INTERNET DOANH NGHIỆP</span><h2 id="<?php echo esc_attr($uid.'-business-heading'); ?>"><?php echo esc_html($c['title']); ?></h2><?php $this->content_paragraphs($c['intro']); ?></header>
            <?php $this->render_package_cards('business',$info,$items); ?>
        </div></section><?php
    }
    private function render_article($settings) {
        $c=$this->content_settings($settings)['article'];if($c['enabled']!=='1')return; ?>
        <section class="fptlp-content-section fptlp-article"><h2><?php echo esc_html($c['title']); ?></h2><?php $this->content_paragraphs($c['intro']); ?>
            <details class="fptlp-article-details"><summary><span class="fptlp-expand-label">Xem thêm bài viết</span><span class="fptlp-collapse-label">Thu gọn bài viết</span><span class="fptlp-details-chevron" aria-hidden="true"></span></summary>
                <div class="fptlp-article-content"><?php foreach($c['sections'] as $section): ?><section><h3><?php echo esc_html($section['heading']); ?></h3><?php $this->content_paragraphs($section['body']); ?></section><?php endforeach; ?>
                <?php if($c['fees']): ?><section class="fptlp-fees"><h3><?php echo esc_html($c['fee_title']); ?></h3><?php $this->content_paragraphs($c['fee_note']); ?><ul><?php foreach($c['fees'] as $fee): ?><li><strong><?php echo esc_html($fee['label']); ?>:</strong> <?php echo esc_html($fee['amount']); ?><?php if($fee['note']!==''): ?> <span>— <?php echo esc_html($fee['note']); ?></span><?php endif; ?></li><?php endforeach; ?></ul></section><?php endif; ?></div>
                <button type="button" class="fptlp-article-collapse" hidden>Thu gọn bài viết ↑</button>
            </details>
        </section><?php
    }
    private function render_price_table($settings) {
        $c=$this->content_settings($settings)['price_table'];
        if ($c['enabled']!=='1' || !$c['plans']) return;
        $uid=wp_unique_id('fptlp-price-table-'); ?>
        <section class="fptlp-content-section fptlp-price-table" aria-labelledby="<?php echo esc_attr($uid); ?>">
            <header class="fptlp-content-heading"><h2 id="<?php echo esc_attr($uid); ?>"><?php echo esc_html($c['title'] ?: 'Bảng giá gói cước'); ?></h2><?php $this->content_paragraphs($c['intro']); ?></header>
            <p class="fptlp-table-hint" id="<?php echo esc_attr($uid.'-hint'); ?>">Vuốt ngang để xem đầy đủ bảng giá →</p>
            <div class="fptlp-table-scroll" tabindex="0" role="region" aria-labelledby="<?php echo esc_attr($uid); ?>" aria-describedby="<?php echo esc_attr($uid.'-hint'); ?>">
                <table class="fptlp-comparison-table"><thead><tr><?php foreach (['column_name','column_price','column_register','column_equipment'] as $field): ?><th scope="col"><?php echo esc_html($c[$field]); ?></th><?php endforeach; ?></tr></thead><tbody>
                <?php foreach ($c['plans'] as $index=>$plan): ?><tr>
                    <th scope="row"><?php echo esc_html($plan['name']); ?></th><td><?php echo esc_html($plan['price']); ?></td>
                    <td><button type="button" class="fptlp-table-register fptlp-popup-open" data-modal="register" data-package="<?php echo esc_attr($plan['name']); ?>" data-fptlp-table-key="<?php echo esc_attr('table:'.$index); ?>" aria-label="<?php echo esc_attr(($c['button_label'] ?: 'Đăng ký').' – '.$plan['name']); ?>"><?php echo esc_html($c['button_label'] ?: 'Đăng ký'); ?></button></td>
                    <td><?php echo esc_html($plan['equipment']); ?></td>
                </tr><?php endforeach; ?></tbody></table>
            </div>
        </section><?php
    }
    private function render_faq($settings) {
        $c=$this->content_settings($settings)['faq'];if($c['enabled']!=='1'||!$c['items'])return; ?>
        <section class="fptlp-content-section fptlp-faq"><h2><?php echo esc_html($c['title']); ?></h2><div class="fptlp-faq-list">
        <?php foreach($c['items'] as $row): ?><details class="fptlp-faq-item"><summary><span><?php echo esc_html($row['question']); ?></span><span class="fptlp-details-chevron" aria-hidden="true"></span></summary><div class="fptlp-faq-answer"><?php $this->content_paragraphs($row['answer']); ?></div></details><?php endforeach; ?>
        </div></section><?php
    }
}
