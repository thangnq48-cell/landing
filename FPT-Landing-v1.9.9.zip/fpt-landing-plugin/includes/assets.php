<?php
if (!defined('ABSPATH')) exit;

trait FPTLP_Assets {
    private function content_uses_landing($value,&$seen) {
        if (is_array($value)) {
            foreach ($value as $key=>$child) {
                if (in_array($key,['template_id','ref'],true) && is_scalar($child) && preg_match('/^[0-9]+$/D',(string)$child) && $this->post_uses_landing((int)$child,$seen)) return true;
                if ($this->content_uses_landing($child,$seen)) return true;
            }
            return false;
        }
        if (!is_string($value)) return false;
        if (has_shortcode($value,'fpt_landing_page')) return true;
        if (has_shortcode($value,'elementor-template') && preg_match_all('/\[elementor-template\s+([^\]]+)\]/',$value,$matches)) {
            foreach ($matches[1] as $attributes) {
                $attrs=shortcode_parse_atts($attributes);
                if (!empty($attrs['id']) && preg_match('/^[0-9]+$/D',(string)$attrs['id']) && $this->post_uses_landing((int)$attrs['id'],$seen)) return true;
            }
        }
        return false;
    }
    private function post_uses_landing($id,&$seen) {
        if (!$id || isset($seen[$id]) || count($seen)>=30) return false;
        $seen[$id]=true;$post=get_post($id);
        if (!$post) return false;
        if ($this->content_uses_landing($post->post_content,$seen)) return true;
        if ($this->content_uses_landing(parse_blocks($post->post_content),$seen)) return true;
        $data=get_post_meta($id,'_elementor_data',true);
        if (is_string($data)) $data=json_decode($data,true);
        return $this->content_uses_landing($data,$seen);
    }
    private function should_load_assets() {
        global $wp_query;
        $ids=is_singular()?[get_queried_object_id()]:wp_list_pluck($wp_query->posts ?? [],'ID');
        $seen=[];$needed=false;
        foreach ($ids as $id) if ($this->post_uses_landing($id,$seen)) { $needed=true;break; }
        return (bool)apply_filters('fptlp_load_assets',$needed);
    }
    private function enqueue_landing_assets() {
        foreach (['fptlp-style','fptlp-catalog','fptlp-content'] as $handle) wp_enqueue_style($handle);
        foreach (['fptlp-script','fptlp-catalog','fptlp-content'] as $handle) wp_enqueue_script($handle);
    }
}
