<?php
if (!defined('ABSPATH')) exit;

trait FPTLP_Registration {
    private function normalize_phone($value) {
        if (!is_string($value) || strlen($value)>24 || !preg_match('/^[0-9+() .-]+$/D', $value)) return '';
        $phone=preg_replace('/[() .-]/', '', $value);
        $phone=preg_replace('/^(?:\+84|0084|84)/', '0', $phone);
        return preg_match('/^(?:0[35789][0-9]{8}|02[0-9]{9})$/D', $phone) ? $phone : '';
    }
    private function request_text($input,$key,$max) {
        $value=$input[$key] ?? '';
        return is_string($value) && strlen($value)<=$max ? sanitize_text_field(wp_unslash($value)) : '';
    }
    private function guard_key($value) { return hash_hmac('sha256',$value,wp_salt('nonce')); }
    /** Atomic DB lock: compare-and-delete prevents an expired owner releasing a new lock. */
    private function acquire_guard($key) {
        $name='fptlp_guard_'.$key;
        $token=(time()+120).':'.wp_generate_uuid4();
        if (add_option($name,$token,'',false)) return $token;
        $old=get_option($name,'');
        if (is_string($old) && (int)$old<time()) {
            $this->release_guard($key,$old);
            if (add_option($name,$token,'',false)) return $token;
        }
        return false;
    }
    private function release_guard($key,$token) {
        global $wpdb;
        $name='fptlp_guard_'.$key;
        $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name = %s AND option_value = %s",$name,$token));
        wp_cache_delete($name,'options');
    }
    public function schedule_guard_cleanup() {
        if (!wp_next_scheduled('fptlp_guard_cleanup')) wp_schedule_event(time()+3600,'daily','fptlp_guard_cleanup');
    }
    public function cleanup_guards() {
        global $wpdb;
        $rows=$wpdb->get_results($wpdb->prepare("SELECT option_name, option_value FROM {$wpdb->options} WHERE option_name LIKE %s AND CAST(option_value AS UNSIGNED) < %d LIMIT 200",$wpdb->esc_like('fptlp_guard_').'%',time()));
        foreach ($rows as $row) $this->release_guard(substr($row->option_name,strlen('fptlp_guard_')),$row->option_value);
    }
    private function process_registration($input,$server) {
        if (($server['REQUEST_METHOD'] ?? '')!=='POST') return 'error';
        $nonce=$this->request_text($input,'fptlp_nonce',100);
        if (!wp_verify_nonce($nonce,'fptlp_submit')) return 'expired';
        if (!empty($input['fptlp_website'])) return 'success';
        $phone=$this->normalize_phone($input['fptlp_phone'] ?? '');
        if ($phone==='') return 'invalid_phone';
        $name=$this->request_text($input,'fptlp_name',400);
        $address=$this->request_text($input,'fptlp_address',1000);
        $package=$this->request_text($input,'fptlp_package',600);
        $kind=$this->request_text($input,'fptlp_kind',20)==='callback'?'callback':'register';
        $key=$this->request_text($input,'fptlp_package_key',80);
        $region=sanitize_title($this->request_text($input,'fptlp_region',200));
        $services=[];
        foreach (['Internet','Truyền hình','Camera'] as $service) {
            if (isset($input['fptlp_services']) && is_array($input['fptlp_services']) && in_array($service,$input['fptlp_services'],true)) $services[]=$service;
        }
        $quote=$this->lead_quote($key,$region,$package);
        if ($quote['package']!=='') $package=$quote['package'];
        $fingerprint=$this->guard_key(wp_json_encode([$phone,$kind,$package,$region,$address,$services]));
        $duplicate='fptlp_duplicate_'.$fingerprint;
        $limits=['phone_'.$this->guard_key($phone)=>3];
        // Do not trust spoofable forwarding headers. Behind a proxy, the host must resolve REMOTE_ADDR.
        $ip=$server['REMOTE_ADDR'] ?? '';
        if (is_string($ip) && filter_var($ip,FILTER_VALIDATE_IP)) {
            $ip=inet_ntop(inet_pton($ip));
            $limits['ip_'.$this->guard_key($ip)]=10;
        }
        ksort($limits);$locks=[];
        try {
            foreach ($limits as $resource=>$limit) {
                $token=$this->acquire_guard($resource);
                if (!$token) return 'busy';
                $locks[$resource]=$token;
            }
            if (get_transient($duplicate)) return 'duplicate';
            $buckets=[];
            foreach ($limits as $resource=>$limit) {
                $bucket=get_transient('fptlp_rate_'.$resource);
                if (!is_array($bucket) || ($bucket['until'] ?? 0)<=time()) $bucket=['count'=>0,'until'=>time()+600];
                if ($bucket['count']>=$limit) return 'rate_limited';
                $buckets[$resource]=$bucket;
            }
            $id=wp_insert_post(['post_type'=>'fptlp_lead','post_status'=>'private','post_title'=>sprintf('%s – %s',$name ?: 'Khách mới',$phone)],true);
            if (is_wp_error($id) || !$id) return 'error';
            $meta=['name'=>$name,'phone'=>$phone,'address'=>$address,'package'=>$package,'kind'=>$kind,'services'=>implode(', ',$services),'created'=>current_time('mysql'),'page'=>esc_url_raw(wp_get_referer() ?: ''),'region'=>$quote['region'],'quote'=>$quote['price'],'price_basis'=>$quote['basis'],'mail_status'=>'pending'];
            foreach ($meta as $field=>$value) update_post_meta($id,'_fptlp_'.$field,$value);
            set_transient($duplicate,$id,600);
            foreach ($buckets as $resource=>$bucket) {
                $bucket['count']++;
                set_transient('fptlp_rate_'.$resource,$bucket,max(1,$bucket['until']-time()));
            }
        } finally {
            foreach ($locks as $resource=>$token) $this->release_guard($resource,$token);
        }
        $this->send_lead_notification($id);
        return 'success';
    }
    private function send_lead_notification($id) {
        $token=$this->acquire_guard('mail_'.(int)$id);
        if (!$token) return 'busy';
        try {
            $last=(int)get_post_meta($id,'_fptlp_mail_attempt_ts',true);
            if ($last && time()-$last<60) return 'cooldown';
            $to=sanitize_email($this->settings()['notification_email']);
            update_post_meta($id,'_fptlp_mail_attempt_ts',time());
            update_post_meta($id,'_fptlp_mail_attempted_at',current_time('mysql'));
            update_post_meta($id,'_fptlp_mail_attempts',1+(int)get_post_meta($id,'_fptlp_mail_attempts',true));
            update_post_meta($id,'_fptlp_mail_to',$to);
            update_post_meta($id,'_fptlp_mail_status','sending');
            if (!is_email($to)) $status='no_recipient';
            else {
                $lines=[];
                foreach (['phone'=>'Số điện thoại','name'=>'Họ tên','address'=>'Địa chỉ','package'=>'Gói','services'=>'Dịch vụ','kind'=>'Loại yêu cầu','region'=>'Khu vực','quote'=>'Giá tham khảo khi tiếp nhận','price_basis'=>'Loại giá'] as $field=>$label) $lines[]=$label.': '.get_post_meta($id,'_fptlp_'.$field,true);
                try {
                    $sent=wp_mail($to,'[FPT Landing] Khách đăng ký mới: '.get_post_meta($id,'_fptlp_phone',true),implode(PHP_EOL,$lines));
                    $status=$sent?'accepted':'failed';
                } catch (\Throwable $error) { $status='failed'; }
            }
            update_post_meta($id,'_fptlp_mail_status',$status);
            return $status;
        } finally { $this->release_guard('mail_'.(int)$id,$token); }
    }
    private function mail_status_label($status) {
        return ['pending'=>'Chờ gửi','sending'=>'Đang gửi (nếu kéo dài, hãy kiểm tra SMTP)','accepted'=>'Hệ thống đã nhận yêu cầu gửi','failed'=>'Gửi lỗi — kiểm tra SMTP','no_recipient'=>'Chưa có email nhận hợp lệ'][$status] ?? 'Chưa có lịch sử gửi';
    }
    public function mail_column($column,$id) {
        if ($column==='fptlp_mail') echo esc_html($this->mail_status_label(get_post_meta($id,'_fptlp_mail_status',true)));
    }
    public function register_mail_box() { add_meta_box('fptlp_mail','Thông báo email',[$this,'mail_box'],'fptlp_lead','side'); }
    public function mail_box($post) {
        if (!current_user_can('manage_options')) return;
        echo '<p><strong>'.esc_html($this->mail_status_label(get_post_meta($post->ID,'_fptlp_mail_status',true))).'</strong></p>';
        foreach (['to'=>'Email nhận gần nhất','attempted_at'=>'Lần thử gần nhất','attempts'=>'Số lần thử'] as $field=>$label) echo '<p>'.esc_html($label).': '.esc_html(get_post_meta($post->ID,'_fptlp_mail_'.$field,true) ?: '—').'</p>';
        echo '<p>Trạng thái đã nhận yêu cầu gửi không xác nhận thư đã vào hộp thư. Gửi lại sử dụng email trong Cài đặt đăng ký.</p>';
        echo '<button type="submit" class="button" form="fptlp-resend-'.(int)$post->ID.'">Gửi lại thông báo</button><p class="description">Mỗi lần cách nhau ít nhất 60 giây.</p>';
    }
    public function resend_form() {
        global $post;
        if (!current_user_can('manage_options') || !$post || $post->post_type!=='fptlp_lead') return;
        // Separate form in the footer: never nest a form inside WordPress's post editor form.
        echo '<form hidden id="fptlp-resend-'.(int)$post->ID.'" method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="fptlp_resend"><input type="hidden" name="lead_id" value="'.(int)$post->ID.'">';
        wp_nonce_field('fptlp_resend_'.$post->ID);echo '</form>';
    }
    public function resend_notification() {
        if (!current_user_can('manage_options') || ($_SERVER['REQUEST_METHOD'] ?? '')!=='POST') wp_die('Không có quyền gửi lại thông báo.','', ['response'=>403]);
        $raw=$_POST['lead_id'] ?? '';
        $id=is_scalar($raw)?absint($raw):0;
        $nonce=$this->request_text($_POST,'_wpnonce',100);
        if (!$id || !wp_verify_nonce($nonce,'fptlp_resend_'.$id)) wp_die('Phiên xác nhận không hợp lệ.','', ['response'=>403]);
        $lead=get_post($id);
        if (!$lead || $lead->post_type!=='fptlp_lead' || $lead->post_status==='trash') wp_die('Không tìm thấy yêu cầu đăng ký.','', ['response'=>404]);
        $status=$this->send_lead_notification($id);
        wp_safe_redirect(add_query_arg('fptlp_mail_result',$status,admin_url('post.php?post='.$id.'&action=edit')));exit;
    }
    public function mail_notice() {
        if (!current_user_can('manage_options') || !isset($_GET['fptlp_mail_result'])) return;
        $status=is_string($_GET['fptlp_mail_result'])?sanitize_key($_GET['fptlp_mail_result']):'';
        $messages=['accepted'=>'Hệ thống đã nhận yêu cầu gửi email. Hãy kiểm tra hộp thư nhận.','failed'=>'Gửi email lỗi. Dữ liệu khách vẫn được lưu. Hãy kiểm tra SMTP trước khi thử lại.','no_recipient'=>'Hãy điền email nhận hợp lệ trong Cài đặt đăng ký.','cooldown'=>'Vui lòng chờ đủ 60 giây sau lần gửi trước.','busy'=>'Thông báo đang được xử lý. Vui lòng thử lại sau.'];
        if (isset($messages[$status])) echo '<div class="notice '.($status==='accepted'?'notice-success':'notice-warning').' is-dismissible"><p>'.esc_html($messages[$status]).'</p></div>';
    }
}
