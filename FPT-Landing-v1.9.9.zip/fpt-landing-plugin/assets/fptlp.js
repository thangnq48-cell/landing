(function(){
  'use strict';

  function initializeCarousel(carousel){
    if(carousel.dataset.fptlpReady === '1') return;
    carousel.dataset.fptlpReady = '1';
    var track = carousel.querySelector('.fptlp-grid');
    var prev = carousel.querySelector('.fptlp-prev');
    var next = carousel.querySelector('.fptlp-next');
    var panel = carousel.closest('.fptlp-tab-panel');
    var counter = panel && panel.querySelector('.fptlp-slide-count');
    if(!track || !prev || !next) return;

    function metrics(){
      var first = track.querySelector('.fptlp-card');
      if(!first) return null;
      var gap = parseFloat(getComputedStyle(track).columnGap) || 0;
      var step = first.getBoundingClientRect().width + gap;
      var total = track.querySelectorAll('.fptlp-card').length;
      var visible = step ? Math.min(total, Math.max(1, Math.round((track.clientWidth + gap) / step))) : 1;
      var firstVisible = Math.min(Math.max(1, Math.round(track.scrollLeft / (step || 1)) + 1), Math.max(1,total - visible + 1));
      return {step:step,total:total,visible:visible,first:firstVisible};
    }
    function update(){
      if(panel && panel.hidden) return;
      var max = Math.max(0, track.scrollWidth - track.clientWidth);
      var canScroll = max > 3;
      carousel.classList.toggle('fptlp-no-scroll', !canScroll);
      prev.disabled = !canScroll || track.scrollLeft <= 3;
      next.disabled = !canScroll || track.scrollLeft >= max-3;
      var m = metrics();
      if(counter && m){
        counter.textContent = 'Gói ' + m.first + '–' + Math.min(m.total,m.first+m.visible-1) + ' / ' + m.total;
      }
    }
    function move(direction){
      var m = metrics();
      if(!m) return;
      track.scrollBy({left:direction*m.step,behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth'});
    }
    prev.addEventListener('click',function(){move(-1);});
    next.addEventListener('click',function(){move(1);});
    track.addEventListener('scroll',update,{passive:true});
    carousel.addEventListener('fptlp:refresh',function(){requestAnimationFrame(update);});
    if(typeof ResizeObserver !== 'undefined') new ResizeObserver(update).observe(track);
    else window.addEventListener('resize',update,{passive:true});
    update();
  }

  function initializeTabs(root){
    var list = root.querySelector('.fptlp-package-tabs');
    if(!list) return;
    var tabs = Array.prototype.slice.call(list.querySelectorAll('[role="tab"]'));
    var panels = tabs.map(function(tab){return document.getElementById(tab.getAttribute('aria-controls'));});
    function centerTab(tab){
      if(!tab) return;
      var tabBox=tab.getBoundingClientRect();
      var listBox=list.getBoundingClientRect();
      var target=list.scrollLeft + (tabBox.left + tabBox.width/2) - (listBox.left + listBox.width/2);
      list.scrollTo({left:target,behavior:'auto'});
    }
    function activate(index, focusTab){
      tabs.forEach(function(tab,i){
        var active = index===i;
        tab.classList.toggle('is-active',active);
        tab.setAttribute('aria-selected',active?'true':'false');
        tab.tabIndex = active ? 0 : -1;
        if(panels[i]) panels[i].hidden = !active;
      });
      if(focusTab) tabs[index].focus();
      centerTab(tabs[index]);
      var activeCarousel = panels[index] && panels[index].querySelector('.fptlp-carousel');
      if(activeCarousel) activeCarousel.dispatchEvent(new Event('fptlp:refresh'));
    }
    requestAnimationFrame(function(){
      centerTab(tabs.find(function(tab){return tab.getAttribute('aria-selected')==='true';}) || tabs[0]);
    });
    tabs.forEach(function(tab,index){
      tab.addEventListener('click',function(){activate(index,false);});
      tab.addEventListener('keydown',function(e){
        var destination;
        if(e.key==='ArrowRight') destination=(index+1)%tabs.length;
        else if(e.key==='ArrowLeft') destination=(index-1+tabs.length)%tabs.length;
        else if(e.key==='Home') destination=0;
        else if(e.key==='End') destination=tabs.length-1;
        else return;
        e.preventDefault(); activate(destination,true);
      });
    });
  }

  function initializePopup(root){
    var modal = root.querySelector('.fptlp-modal');
    if(!modal) return;
    var panel = modal.querySelector('.fptlp-modal-panel');
    var form = modal.querySelector('form');
    var packageInput = form.querySelector('[name=fptlp_package]');
    var kindInput = form.querySelector('[name=fptlp_kind]');
    var heading = modal.querySelector('[data-fptlp-modal-title]');
    var registrationHeading = heading.textContent;
    var phone = form.querySelector('[name=fptlp_phone]');
    var submitButton = form.querySelector('.fptlp-popup-submit');
    var submitting = false;
    function normalizedPhone(value){
      if(value.length>24 || !/^[0-9+() .-]+$/.test(value)) return '';
      var number=value.replace(/[() .-]/g,'').replace(/^(?:\+84|0084|84)/,'0');
      return /^(?:0[35789][0-9]{8}|02[0-9]{9})$/.test(number)?number:'';
    }
    phone.addEventListener('input',function(){phone.setCustomValidity('');});
    form.addEventListener('submit',function(event){
      if(submitting){event.preventDefault();return;}
      if(event.defaultPrevented) return;
      var number=normalizedPhone(phone.value);
      if(!number){
        event.preventDefault();
        phone.setCustomValidity('Vui lòng nhập số di động hoặc số cố định Việt Nam hợp lệ; có thể dùng +84.');
        phone.reportValidity();return;
      }
      phone.value=number;
      submitting=true;
      submitButton.disabled=true;
      submitButton.textContent='Đang gửi…';
      form.setAttribute('aria-busy','true');
    });
    window.addEventListener('pageshow',function(){
      submitting=false;submitButton.disabled=false;form.removeAttribute('aria-busy');
      submitButton.textContent=kindInput.value==='callback'?'Yêu cầu gọi lại ›':'Đăng ký nhanh ›';
    });
    var lastFocus = null;
    var previousOverflow = '';
    function open(kind,pkg){
      lastFocus = document.activeElement;
      previousOverflow = document.body.style.overflow;
      modal.hidden=false;
      var callback = kind === 'callback';
      modal.classList.toggle('is-callback',callback);
      kindInput.value=callback?'callback':'register';
      packageInput.value=pkg||'';
      heading.textContent=callback?'Yêu cầu gọi lại':registrationHeading;
      var extra=form.querySelector('.fptlp-register-extra');
      if(extra){
        extra.hidden=callback;
        extra.querySelectorAll('input,select,textarea').forEach(function(field){field.disabled=callback;});
      }
      form.querySelector('.fptlp-popup-submit').textContent=callback?'Yêu cầu gọi lại ›':'Đăng ký nhanh ›';
      document.body.style.overflow='hidden';
      setTimeout(function(){if(!modal.hidden && phone) phone.focus();},50);
    }
    function close(){
      modal.hidden=true;
      document.body.style.overflow=previousOverflow;
      if(lastFocus && typeof lastFocus.focus === 'function') lastFocus.focus();
    }
    root.addEventListener('click',function(e){
      var trigger = e.target.closest('.fptlp-popup-open');
      if(trigger){e.preventDefault();open(trigger.dataset.modal||'register',trigger.dataset.package||'');}
      if(e.target.closest('[data-close-modal]')) close();
      var expand=e.target.closest('.fptlp-expand');
      if(expand){
        var card=expand.closest('.fptlp-card');
        if(!card) return;
        var currentlyExpanded = expand.getAttribute('aria-expanded')==='true';
        card.querySelectorAll('.fptlp-benefit-extra').forEach(function(el){el.hidden=currentlyExpanded;});
        expand.setAttribute('aria-expanded',currentlyExpanded?'false':'true');
        expand.textContent=currentlyExpanded?'Xem chi tiết':'Thu gọn';
      }
    });
    document.addEventListener('keydown',function(e){
      if(modal.hidden) return;
      if(e.key === 'Escape'){e.preventDefault();close();return;}
      if(e.key!=='Tab') return;
      var focusable=Array.prototype.slice.call(panel.querySelectorAll('button,input:not([disabled]),select:not([disabled]),a[href]')).filter(function(el){return el.offsetParent!==null && !el.closest('[hidden]');});
      if(!focusable.length) return;
      var first=focusable[0],last=focusable[focusable.length-1];
      if(e.shiftKey && document.activeElement===first){e.preventDefault();last.focus();}
      else if(!e.shiftKey && document.activeElement===last){e.preventDefault();first.focus();}
    });
  }

  function ready(){
    document.querySelectorAll('.fptlp').forEach(function(root){
      if(root.dataset.fptlpInitialized === '1') return;
      root.dataset.fptlpInitialized = '1';
      root.querySelectorAll('.fptlp-carousel').forEach(initializeCarousel);
      initializeTabs(root);
      initializePopup(root);
    });
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',ready);
  else ready();
})();
