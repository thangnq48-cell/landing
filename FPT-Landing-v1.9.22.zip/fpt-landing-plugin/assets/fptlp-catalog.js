(function () {
  'use strict';
  var storageKey = 'fptlp-region-v1';
  function initVisuals(root) {
    root.querySelectorAll('.fptlp-card-banner img').forEach(function (image) {
      function fit() {
        if (!image.naturalWidth || !image.naturalHeight) return;
        var card = image.closest('.fptlp-card');
        var width = Math.min(100, (image.naturalWidth / image.naturalHeight) / (62 / 45) * 100);
        card.style.setProperty('--fptlp-banner-width', width + '%');
      }
      image.addEventListener('load', fit);
      if (image.complete) fit();
    });
    var meters=[];
    root.querySelectorAll('[data-fptlp-meter]').forEach(function (meter) {
      if (meter.dataset.fptlpMeterReady) return;
      meter.dataset.fptlpMeterReady='1';
      var box=meter.closest('.fptlp-speed-box'),needle=meter.querySelector('.fptlp-needle'),arc=meter.querySelector('.fptlp-meter-fill');
      if(!box || !needle || !arc)return;
      function readout(selector,key){
        var node=box.querySelector(selector),raw=meter.dataset[key],value=raw!==''?Number(raw):NaN;
        return {node:node,value:value,final:node?node.textContent:''};
      }
      meters.push({element:meter,needle:needle,arc:arc,target:Math.max(0,Math.min(1,Number(meter.dataset.target)||0)),down:readout('.fptlp-dl .fptlp-speed-number','down'),up:readout('.fptlp-ul .fptlp-speed-number','up')});
    });
    if(meters.length){
      var sweep=1100,back=380,total=sweep+back,frame=0;
      var preference=window.matchMedia('(prefers-reduced-motion: reduce)');
      function clamp(t){return Math.max(0,Math.min(1,t));}
      function ease(t){return t<.5?4*t*t*t:1-Math.pow(-2*t+2,3)/2;}
      function count(readout,progress){
        if(!readout.node || !Number.isFinite(readout.value))return;
        var value=Math.floor(readout.value*progress);
        var text=progress>=1?readout.final:(value>=1000?Number((value/1000).toFixed(3))+' Gbps':value+' Mbps');
        if(readout.node.textContent!==text)readout.node.textContent=text;
      }
      function render(elapsed){
        meters.forEach(function(m){
          var progress=elapsed<=sweep?ease(clamp(elapsed/sweep)):1-(1-m.target)*(1-Math.pow(1-clamp((elapsed-sweep)/back),3));
          var angle=-180+180*progress,radians=angle*Math.PI/180;
          m.needle.setAttribute('transform','rotate('+angle+' 50 50)');
          m.arc.setAttribute('d','M8 50 A42 42 0 0 1 '+(50+42*Math.cos(radians))+' '+(50+42*Math.sin(radians)));
          m.arc.setAttribute('visibility',progress>0?'visible':'hidden');
          var duration=m.target===1?sweep:total;
          var numberProgress=elapsed>=duration?1:.999999*ease(clamp(elapsed/duration));
          count(m.down,numberProgress);count(m.up,numberProgress);
        });
      }
      function clean(){
        if(preference.removeEventListener)preference.removeEventListener('change',motionChange);
        else if(preference.removeListener)preference.removeListener(motionChange);
        meters.forEach(function(m){m.element.dataset.fptlpMeterRunning='0';});
      }
      function finish(){cancelAnimationFrame(frame);render(total);clean();}
      function motionChange(event){if(event.matches)finish();}
      if(preference.matches || typeof requestAnimationFrame!=='function'){
        // Server markup already contains final text and gauge angle.
        clean();
      }else{
        if(preference.addEventListener)preference.addEventListener('change',motionChange);
        else if(preference.addListener)preference.addListener(motionChange);
        meters.forEach(function(m){m.element.dataset.fptlpMeterRunning='1';});
        render(0);
        var started=performance.now();
        function tick(now){
          var elapsed=Math.min(total,now-started);render(elapsed);
          if(elapsed<total)frame=requestAnimationFrame(tick);else clean();
        }
        frame=requestAnimationFrame(tick);
      }
    }
    if (!window.CSS || !CSS.supports('container-type', 'inline-size')) {
      root.querySelectorAll('.fptlp-carousel').forEach(function (carousel) {
        var track = carousel.querySelector('.fptlp-grid');
        function columns() {
          var width = carousel.clientWidth;
          track.dataset.fptlpColumns = width >= 1080 ? '4' : width >= 780 ? '3' : width >= 540 ? '2' : '1';
        }
        columns();
        if (typeof ResizeObserver !== 'undefined') new ResizeObserver(columns).observe(carousel);
        else {
          window.addEventListener('resize', columns, {passive:true});
          carousel.addEventListener('fptlp:refresh', columns);
        }
      });
    }
  }
  function init(root) {
    if (root.dataset.fptlpCatalogReady) return;
    root.dataset.fptlpCatalogReady = '1';
    initVisuals(root);
    var select = root.querySelector('[data-fptlp-region]');
    var cards = Array.from(root.querySelectorAll('[data-fptlp-package-key]'));
    var current = null;
    function selectedRegion() { return select ? select.value : ''; }
    function closeQuick(focus) {
      if (!current) return;
      var previous = current; current = null;
      previous.panel.hidden = true;
      previous.card.classList.remove('is-quick-open');
      previous.siblings.forEach(function (row) { row.node.inert = row.inert; });
      previous.button.setAttribute('aria-expanded', 'false');
      if (focus) previous.button.focus({preventScroll: true});
    }
    function openQuick(card, button) {
      closeQuick(false);
      var panel = card.querySelector('.fptlp-quick-panel');
      if (!panel) return;
      var siblings = Array.from(card.children).filter(function (node) { return node !== panel; }).map(function (node) {
        var row = {node: node, inert: node.inert}; node.inert = true; return row;
      });
      current = {card: card, panel: panel, button: button, siblings: siblings};
      panel.hidden = false; card.classList.add('is-quick-open');
      button.setAttribute('aria-expanded', 'true'); panel.focus({preventScroll: true});
    }
    function updatePrices() {
      var region = selectedRegion();
      var label = select && select.selectedOptions.length ? select.selectedOptions[0].textContent : '';
      cards.forEach(function (card) {
        var prices = {};
        try { prices = JSON.parse(card.dataset.fptlpPrices || '{}'); } catch (_) {}
        var specific = region && Object.prototype.hasOwnProperty.call(prices, region);
        var price = specific ? prices[region].price : card.dataset.fptlpBasePrice;
        card.querySelectorAll('[data-fptlp-price]').forEach(function (el) { el.textContent = price; });
        card.querySelectorAll('[data-fptlp-price-note]').forEach(function (el) {
          el.hidden = !region;
          el.textContent = specific ? 'Giá tại ' + label : 'Chưa cập nhật giá riêng tại ' + label + '. Đang hiển thị giá tham khảo.';
          el.classList.toggle('is-fallback', !!region && !specific);
        });
      });
      var status = root.querySelector('[data-fptlp-region-status]');
      if (status) status.textContent = region ? 'Đang xem khu vực: ' + label + '. Giá được cập nhật trên từng gói.' : 'Đang xem giá tham khảo. Chọn khu vực để xem giá đã cập nhật.';
    }
    if (select) {
      try {
        var saved = localStorage.getItem(storageKey);
        if (Array.from(select.options).some(function (option) { return option.value === saved; })) select.value = saved;
      } catch (_) {}
      select.addEventListener('change', function () {
        updatePrices();
        try { localStorage.setItem(storageKey, select.value); } catch (_) {}
        document.querySelectorAll('.fptlp').forEach(function (other) {
          if (other !== root) other.dispatchEvent(new CustomEvent('fptlp:region', {detail: select.value}));
        });
      });
      root.addEventListener('fptlp:region', function (event) {
        select.value = Array.from(select.options).some(function (option) { return option.value === event.detail; }) ? event.detail : '';
        updatePrices();
      });
    }
    updatePrices();
    cards.forEach(function (card, index) {
      var button = card.querySelector('.fptlp-quick-open');
      var panel = card.querySelector('.fptlp-quick-panel');
      if (button && panel) {
        var uid = root.querySelector('.fptlp-popup-form').id + '-quick-' + index;
        panel.id = uid; button.setAttribute('aria-controls', uid);
      }
    });
    root.addEventListener('click', function (event) {
      var open = event.target.closest('.fptlp-quick-open');
      if (open) { event.preventDefault(); openQuick(open.closest('.fptlp-card'), open); }
      if (event.target.closest('.fptlp-quick-close')) { event.preventDefault(); closeQuick(true); }
      if (event.target.closest('.fptlp-package-tab')) closeQuick(false);
    });
    // Capture the chosen package and area before the existing popup handler opens.
    root.addEventListener('click', function (event) {
      if (!event.target.closest('.fptlp-popup-open')) return;
      var form = root.querySelector('.fptlp-popup-form');
      var card = event.target.closest('[data-fptlp-package-key]');
      form.elements.fptlp_region.value = selectedRegion();
      form.elements.fptlp_package_key.value = card ? card.dataset.fptlpPackageKey : (event.target.closest('.fptlp-popup-open').dataset.fptlpTableKey || '');
    }, true);
    root.addEventListener('keydown', function (event) {
      if (event.target.closest('.fptlp-package-tab') && ['ArrowRight','ArrowLeft','Home','End'].includes(event.key)) closeQuick(false);
    });
    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape' && current && !event.defaultPrevented && root.querySelector('.fptlp-modal').hidden) {
        event.preventDefault(); closeQuick(true);
      }
    });
  }
  function ready() { document.querySelectorAll('.fptlp').forEach(init); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', ready); else ready();
})();
