jQuery(function ($) {
  'use strict';
  var root = document.querySelector('.fptlp-admin');
  if (!root) return;
  var counter = 0;
  var dirty = false;
  var mediaFrame = null;
  var mediaField = null;
  var form = root.querySelector('form');
  function changed() { dirty = true; }
  function announce(text) { $(root).find('.fptlp-admin-status').text(text); }
  function show(key) {
    $(root).find('.fptlp-admin-tab').each(function () {
      var active = this.dataset.adminTab === key;
      $(this).toggleClass('button-primary', active).attr('aria-pressed', String(active));
    });
    $(root).find('.fptlp-admin-category').each(function () { this.hidden = this.dataset.adminPanel !== key; });
  }
  function update(panel) {
    var cards = $(panel).find('.fptlp-package-list > .fptlp-package-editor');
    $(panel).find('.fptlp-package-count').text('(' + cards.length + ' gói)');
    $(panel).find('.fptlp-empty-group').prop('hidden', cards.length !== 0);
    $(panel).find('.fptlp-limit-note').prop('hidden', cards.length <= 6);
    cards.each(function (i) {
      $(this).find('.fptlp-move-up').prop('disabled', i === 0);
      $(this).find('.fptlp-move-down').prop('disabled', i === cards.length - 1);
    });
  }
  function preview(field, url) {
    field.find('.fptlp-image-value').val(url).trigger('change');
    var img = field.find('img');
    if (url) img.attr('src', url); else img.removeAttr('src');
    img.prop('hidden', !url);
    field.find('.fptlp-image-empty').prop('hidden', !!url);
    field.find('.fptlp-remove-image').prop('hidden', !url);
    field.find('.fptlp-pick-image').text(url ? 'Đổi ảnh' : 'Chọn ảnh');
  }
  $(root).on('click', '.fptlp-pick-image', function (event) {
    event.preventDefault();
    if (!window.wp || typeof window.wp.media !== 'function') {
      window.alert('Thư viện ảnh WordPress chưa tải được. Vui lòng tải lại trang quản trị và thử lại.');
      return;
    }
    mediaField = $(this).closest('.fptlp-image-field');
    if (!mediaFrame) {
      mediaFrame = wp.media({title: 'Chọn hình ảnh', button: {text: 'Dùng ảnh này'}, multiple: false, library: {type: 'image'}});
      // WordPress activates the default state while rendering the modal on open.
      // Reading state().get(...) before that first open throws and prevents the dialog.
      mediaFrame.on('open', function () {
        var state = mediaFrame.state();
        var selection = state && state.get('selection');
        if (selection) selection.reset();
      });
      mediaFrame.on('select', function () {
        var state = mediaFrame.state();
        var selection = state && state.get('selection');
        var selected = selection && selection.first();
        if (!selected || !mediaField || !root.contains(mediaField[0])) return;
        var item = selected.toJSON();
        if (item.url) preview(mediaField, item.url);
      });
    }
    mediaFrame.open();
  }).on('click', '.fptlp-remove-image', function () {
    preview($(this).closest('.fptlp-image-field'), '');
  }).on('click', '.fptlp-admin-tab', function () {
    show(this.dataset.adminTab);
  }).on('click', '.fptlp-add-package', function () {
    var panel = this.closest('.fptlp-admin-category');
    var html = panel.querySelector('template').innerHTML.replace(/__INDEX__/g, 'new_' + (++counter));
    var card = $(html).appendTo($(panel).find('.fptlp-package-list'));
    update(panel); changed();
    card.find('[data-field="name"]').trigger('focus');
    announce('Đã thêm gói cước mới.');
  }).on('click', '.fptlp-remove-package', function () {
    var card = this.closest('.fptlp-package-editor');
    if (!window.confirm('Xóa gói “' + card.querySelector('[data-field="name"]').value + '”? Bấm Lưu để áp dụng.')) return;
    var panel = card.closest('.fptlp-admin-category');
    card.remove(); update(panel); changed();
    $(panel).find('.fptlp-add-package').trigger('focus');
    announce('Đã xóa gói cước khỏi danh sách đang sửa.');
  }).on('click', '.fptlp-move-up, .fptlp-move-down', function () {
    var card = $(this).closest('.fptlp-package-editor');
    if ($(this).hasClass('fptlp-move-up')) card.prev().before(card); else card.next().after(card);
    update(card.closest('.fptlp-admin-category')[0]); changed(); this.focus();
    announce('Đã đổi thứ tự gói cước.');
  }).on('click', '.fptlp-add-benefit', function () {
    var fieldset = $(this).closest('fieldset');
    var name = $(this).closest('.fptlp-package-editor').find('[data-field="name"]').attr('name').replace(/\[name\]$/, '[benefits][]');
    var row = $('<div class="fptlp-benefit-row">');
    $('<input type="text" aria-label="Quyền lợi" placeholder="Nhập quyền lợi">').attr('name', name).appendTo(row);
    $('<button type="button" class="button fptlp-remove-benefit" aria-label="Xóa quyền lợi">×</button>').appendTo(row);
    row.appendTo(fieldset.find('.fptlp-benefit-list')).find('input').trigger('focus'); changed();
  }).on('click', '.fptlp-remove-benefit', function () {
    var fieldset = $(this).closest('fieldset');
    $(this).closest('.fptlp-benefit-row').remove(); changed();
    fieldset.find('.fptlp-add-benefit').trigger('focus');
  }).on('input', '[data-field="name"]', function () {
    $(this).closest('.fptlp-package-editor').find('.fptlp-package-title').text(this.value || 'Gói cước mới');
  }).on('input change', 'input, textarea, select', changed);
  $(root).find('.fptlp-admin-category').each(function () { update(this); });
  if (root.querySelector('.fptlp-admin-tab')) show($('#fptlp_first_group').val());
  // Validate only the first invalid field, so later hidden tabs cannot steal focus.
  if (form) {
    form.addEventListener('invalid', function (event) {
      var panel = event.target.closest('.fptlp-admin-category');
      var card = event.target.closest('details');
      if (panel) show(panel.dataset.adminPanel);
      if (card) card.open = true;
    }, true);
    form.noValidate = true;
    form.addEventListener('submit', function (event) {
      var invalid = Array.prototype.find.call(form.elements, function (field) {
        return field.willValidate && !field.validity.valid;
      });
      if (invalid) {
        event.preventDefault();
        var panel = invalid.closest('.fptlp-admin-category');
        var card = invalid.closest('details');
        if (panel) show(panel.dataset.adminPanel);
        if (card) card.open = true;
        invalid.focus();
        invalid.reportValidity();
        return;
      }
      dirty = false;
    });
  }
  window.addEventListener('beforeunload', function (event) {
    if (!dirty) return;
    event.preventDefault(); event.returnValue = '';
  });
});
