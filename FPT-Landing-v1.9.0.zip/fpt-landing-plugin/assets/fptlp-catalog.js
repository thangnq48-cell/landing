(function () {
  'use strict';
  var storageKey = 'fptlp-region-v1';
  function init(root) {
    if (root.dataset.fptlpCatalogReady) return;
    root.dataset.fptlpCatalogReady = '1';
    var select = root.querySelector('[data-fptlp-region]');
    var cards = Array.from(root.querySelectorAll('[data-fptlp-package-key]'));
    var current = null;
    function selectedRegion() { return select ? select.value : ''; }
    function closeQuick(focus) {
      if (!current) return;
      var previous = current; current = null;
      previous.panel.hidden = true;
      previous.card.classList.remove('is-quick-open');
      previous.siblings.forEach(function (row) { row.node.inert = row.inert; });
      previous.button.setAttribute('aria-expanded', 'false');
      if (focus) previous.button.focus({preventScroll: true});
    }
    function openQuick(card, button) {
      closeQuick(false);
      var panel = card.querySelector('.fptlp-quick-panel');
      if (!panel) return;
      var siblings = Array.from(card.children).filter(function (node) { return node !== panel; }).map(function (node) {
        var row = {node: node, inert: node.inert}; node.inert = true; return row;
      });
      current = {card: card, panel: panel, button: button, siblings: siblings};
      panel.hidden = false; card.classList.add('is-quick-open');
      button.setAttribute('aria-expanded', 'true'); panel.focus({preventScroll: true});
    }
    function updatePrices() {
      var region = selectedRegion();
      var label = select && select.selectedOptions.length ? select.selectedOptions[0].textContent : '';
      cards.forEach(function (card) {
        var prices = {};
        try { prices = JSON.parse(card.dataset.fptlpPrices || '{}'); } catch (_) {}
        var specific = region && Object.prototype.hasOwnProperty.call(prices, region);
        var price = specific ? prices[region].price : card.dataset.fptlpBasePrice;
        card.querySelectorAll('[data-fptlp-price]').forEach(function (el) { el.textContent = price; });
        card.querySelectorAll('[data-fptlp-price-note]').forEach(function (el) {
          el.hidden = !region;
          el.textContent = specific ? 'Giá tại ' + label : 'Chưa cập nhật giá riêng tại ' + label + '. Đang hiển thị giá tham khảo.';
          el.classList.toggle('is-fallback', !!region && !specific);
        });
      });
      var status = root.querySelector('[data-fptlp-region-status]');
      if (status) status.textContent = region ? 'Đang xem khu vực: ' + label + '. Giá được cập nhật trên từng gói.' : 'Đang xem giá tham khảo. Chọn khu vực để xem giá đã cập nhật.';
    }
    if (select) {
      try {
        var saved = localStorage.getItem(storageKey);
        if (Array.from(select.options).some(function (option) { return option.value === saved; })) select.value = saved;
      } catch (_) {}
      select.addEventListener('change', function () {
        updatePrices();
        try { localStorage.setItem(storageKey, select.value); } catch (_) {}
        document.querySelectorAll('.fptlp').forEach(function (other) {
          if (other !== root) other.dispatchEvent(new CustomEvent('fptlp:region', {detail: select.value}));
        });
      });
      root.addEventListener('fptlp:region', function (event) {
        select.value = Array.from(select.options).some(function (option) { return option.value === event.detail; }) ? event.detail : '';
        updatePrices();
      });
    }
    updatePrices();
    cards.forEach(function (card, index) {
      var button = card.querySelector('.fptlp-quick-open');
      var panel = card.querySelector('.fptlp-quick-panel');
      if (button && panel) {
        var uid = root.querySelector('.fptlp-popup-form').id + '-quick-' + index;
        panel.id = uid; button.setAttribute('aria-controls', uid);
      }
    });
    root.addEventListener('click', function (event) {
      var open = event.target.closest('.fptlp-quick-open');
      if (open) { event.preventDefault(); openQuick(open.closest('.fptlp-card'), open); }
      if (event.target.closest('.fptlp-quick-close')) { event.preventDefault(); closeQuick(true); }
      if (event.target.closest('.fptlp-package-tab')) closeQuick(false);
    });
    // Capture the chosen package and area before the existing popup handler opens.
    root.addEventListener('click', function (event) {
      if (!event.target.closest('.fptlp-popup-open')) return;
      var form = root.querySelector('.fptlp-popup-form');
      var card = event.target.closest('[data-fptlp-package-key]');
      form.elements.fptlp_region.value = selectedRegion();
      form.elements.fptlp_package_key.value = card ? card.dataset.fptlpPackageKey : '';
    }, true);
    root.addEventListener('keydown', function (event) {
      if (event.target.closest('.fptlp-package-tab') && ['ArrowRight','ArrowLeft','Home','End'].includes(event.key)) closeQuick(false);
    });
    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape' && current && !event.defaultPrevented && root.querySelector('.fptlp-modal').hidden) {
        event.preventDefault(); closeQuick(true);
      }
    });
  }
  function ready() { document.querySelectorAll('.fptlp').forEach(init); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', ready); else ready();
})();
